import random
NameOfDistrics = ["ST", "BD", "BTL", "CG", "DD", "HBT"]
population = [150300, 247100, 333300, 266800, 420900, 318000]
areas = [117.43, 9.22, 43.35, 12.04, 9.96, 10.09]


def max_min_Population(list):
    max = 0
    min = list[0]
    locationOfMax = 0
    locationOfMin = 0
    for (index, x) in enumerate(list):
        if(max < x):
            max = x
            locationOfMax = index
        if(x <= min):
            min = x
            locationOfMin = index
    print(NameOfDistrics[locationOfMax], " has max population: ", max)
    print(NameOfDistrics[locationOfMin], " has min population: ", min)

density = []

for (index, val) in enumerate(population):
        density.append(val // areas[index])
print(NameOfDistrics)
print(population)
print(areas)
print(density)
max_min_Population(population)
