import random


def getNumber():
    number = random.randint(0, 50)
    return number



def play():
    print("Freaking Math.....")

    score = 0
    isContinue = True

    while isContinue:
        # get two random number
        numberA = getNumber()
        numberB = getNumber()

        # make result
        luck = random.randint(-1, 1)

        calculator = random.randint(-5, 5)

        if (calculator > 0):
            # Summation
            realResult = numberA + numberB

            if (luck == 1):
                print(numberA, "+", numberB, "=", realResult, "?")
                userInput = input("[T/F] ")
                if userInput == "f":
                    isContinue = False
                elif userInput == "t":
                    score += 1
            else:
                print(numberA, "+", numberB, "=", realResult*luck, "?")
                userInput = input("[T/F] ")
                if userInput == "t":
                    isContinue = False
                elif userInput == "f":
                    score += 1
        else:
            # Subtraction
            realResult = numberA - numberB

            if (luck == 1):
                print(numberA, "-", numberB, "=", realResult, "?")
                userInput = input("[T/F] ")
                if userInput == "f":
                    isContinue = False
                elif userInput == "t":
                    score += 1
            else:
                print(numberA, "-", numberB, "=", realResult*luck, "?")
                userInput = input("[T/F] ")
                if userInput == "t":
                    isContinue = False
                elif userInput == "f":
                    score += 1

        print("Your score:", score,"\n")

        if (isContinue == False):
            print("Game Over!!!!!!")
            break

play()
