storeOfQuantity = {"HP": 20, "DELL": 50, "MACBOOK": 12, "ASUS": 30}
print(storeOfQuantity)

print("The number of MacBook: ", storeOfQuantity["MACBOOK"])
storeOfQuantity.update({'TOSHIBA': 10})
print(storeOfQuantity)

storeOfPrice = {"HP": 600, "DELL": 650, "MACBOOK": 12000, "ASUS": 400,
                "ACER": 350, "TOSHIBA": 600, "FUJITSU": 900, "ALIENWARE": 1000}

def bill(name, quantity):
    return quantity*storeOfPrice[name]

ItemSell = "ASUS"
NumberOfItem = 5

print(NumberOfItem,"ASUS's pc has price:",bill(ItemSell,NumberOfItem))